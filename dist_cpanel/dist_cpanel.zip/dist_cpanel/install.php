<?php
/**
 * SDC Webform Installation Script
 * This script helps set up the database and configuration for cPanel deployment
 */

// Prevent direct access from web
if (!isset($_SERVER['HTTP_HOST'])) {
    die("This script must be run from the command line or web browser.\n");
}

// Configuration check
$configFile = __DIR__ . '/api/config.php';
if (!file_exists($configFile)) {
    die("Error: config.php not found. Please upload all files first.");
}

require_once $configFile;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SDC Webform Installation</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
            <div class="text-center">
                <h2 class="mt-6 text-3xl font-extrabold text-gray-900">
                    SDC Webform Installation
                </h2>
                <p class="mt-2 text-sm text-gray-600">
                    Complete the installation process
                </p>
            </div>

            <?php
            $step = $_GET['step'] ?? '1';

            if ($step == '1') {
                // Step 1: Configuration check
                ?>
                <div class="bg-white p-8 rounded-lg shadow">
                    <h3 class="text-lg font-medium mb-4">Step 1: Configuration Check</h3>

                    <?php
                    $checks = [
                        'PHP Version (>= 7.4)' => version_compare(PHP_VERSION, '7.4.0', '>='),
                        'PDO Extension' => extension_loaded('pdo'),
                        'PDO MySQL Extension' => extension_loaded('pdo_mysql'),
                        'JSON Extension' => extension_loaded('json'),
                        'Mail Function' => function_exists('mail'),
                        'Config File Writable' => is_writable(dirname($configFile))
                    ];

                    $allPassed = true;
                    foreach ($checks as $check => $passed) {
                        $allPassed = $allPassed && $passed;
                        $icon = $passed ? '✅' : '❌';
                        $class = $passed ? 'text-green-600' : 'text-red-600';
                        echo "<div class='flex justify-between py-2'>";
                        echo "<span>{$check}</span>";
                        echo "<span class='{$class}'>{$icon}</span>";
                        echo "</div>";
                    }
                    ?>

                    <?php if ($allPassed): ?>
                        <div class="mt-6">
                            <a href="?step=2" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                Continue to Database Setup
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="mt-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
                            Please fix the failed requirements before continuing.
                        </div>
                    <?php endif; ?>
                </div>
                <?php
            } elseif ($step == '2') {
                // Step 2: Database setup
                ?>
                <div class="bg-white p-8 rounded-lg shadow">
                    <h3 class="text-lg font-medium mb-4">Step 2: Database Configuration</h3>

                    <?php if ($_POST): ?>
                        <div class="mb-4 p-4 bg-blue-100 border border-blue-400 text-blue-700 rounded">
                            Testing database connection...
                        </div>

                        <?php
                        try {
                            $host = $_POST['db_host'];
                            $name = $_POST['db_name'];
                            $user = $_POST['db_user'];
                            $pass = $_POST['db_pass'];

                            $pdo = new PDO("mysql:host={$host};dbname={$name};charset=utf8mb4", $user, $pass);
                            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                            // Test connection
                            $pdo->query("SELECT 1");

                            echo "<div class='mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded'>";
                            echo "✅ Database connection successful!";
                            echo "</div>";

                            // Store config for next step
                            session_start();
                            $_SESSION['db_config'] = [
                                'host' => $host,
                                'name' => $name,
                                'user' => $user,
                                'pass' => $pass
                            ];

                            echo "<a href='?step=3' class='w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'>";
                            echo "Continue to Table Creation";
                            echo "</a>";

                        } catch (PDOException $e) {
                            echo "<div class='mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded'>";
                            echo "❌ Database connection failed: " . htmlspecialchars($e->getMessage());
                            echo "</div>";
                            $step = '2'; // Show form again
                        }
                        ?>
                    <?php endif; ?>

                    <?php if (!$_POST || isset($e)): ?>
                    <form method="POST" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Database Host</label>
                            <input type="text" name="db_host" value="localhost" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">Database Name</label>
                            <input type="text" name="db_name" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <p class="mt-1 text-sm text-gray-500">Create this database in cPanel first</p>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">Database Username</label>
                            <input type="text" name="db_user" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">Database Password</label>
                            <input type="password" name="db_pass" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>

                        <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Test Database Connection
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
                <?php
            } elseif ($step == '3') {
                // Step 3: Create tables
                ?>
                <div class="bg-white p-8 rounded-lg shadow">
                    <h3 class="text-lg font-medium mb-4">Step 3: Create Database Tables</h3>

                    <?php
                    session_start();
                    if (!isset($_SESSION['db_config'])) {
                        echo "<div class='p-4 bg-red-100 border border-red-400 text-red-700 rounded'>";
                        echo "Session expired. Please <a href='?step=2' class='underline'>start over</a>.";
                        echo "</div>";
                        exit;
                    }

                    $config = $_SESSION['db_config'];

                    try {
                        $pdo = new PDO("mysql:host={$config['host']};dbname={$config['name']};charset=utf8mb4",
                                      $config['user'], $config['pass']);
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                        // Read and execute SQL file
                        $sql = file_get_contents(__DIR__ . '/database_setup.sql');
                        $statements = array_filter(array_map('trim', explode(';', $sql)));

                        foreach ($statements as $statement) {
                            if (empty($statement) || strpos($statement, '--') === 0) continue;
                            $pdo->exec($statement);
                        }

                        echo "<div class='mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded'>";
                        echo "✅ Database tables created successfully!";
                        echo "</div>";

                        // Update config file
                        $configContent = file_get_contents($configFile);
                        $configContent = str_replace("'your_database_name'", "'{$config['name']}'", $configContent);
                        $configContent = str_replace("'your_database_user'", "'{$config['user']}'", $configContent);
                        $configContent = str_replace("'your_database_password'", "'{$config['pass']}'", $configContent);
                        $configContent = str_replace("'localhost'", "'{$config['host']}'", $configContent);

                        file_put_contents($configFile, $configContent);

                        echo "<div class='mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded'>";
                        echo "✅ Configuration file updated!";
                        echo "</div>";

                        echo "<a href='?step=4' class='w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'>";
                        echo "Continue to Email Setup";
                        echo "</a>";

                    } catch (Exception $e) {
                        echo "<div class='p-4 bg-red-100 border border-red-400 text-red-700 rounded'>";
                        echo "❌ Error creating tables: " . htmlspecialchars($e->getMessage());
                        echo "</div>";
                    }
                    ?>
                </div>
                <?php
            } elseif ($step == '4') {
                // Step 4: Email configuration
                ?>
                <div class="bg-white p-8 rounded-lg shadow">
                    <h3 class="text-lg font-medium mb-4">Step 4: Email Configuration</h3>

                    <?php if ($_POST): ?>
                        <div class="mb-4 p-4 bg-blue-100 border border-blue-400 text-blue-700 rounded">
                            Updating email configuration...
                        </div>

                        <?php
                        try {
                            $configContent = file_get_contents($configFile);
                            $configContent = str_replace("'your-email@yourdomain.com'", "'{$_POST['email_user']}'", $configContent);
                            $configContent = str_replace("'admin@yourdomain.com'", "'{$_POST['admin_email']}'", $configContent);
                            $configContent = str_replace("'SDC Creative Studio'", "'{$_POST['admin_name']}'", $configContent);

                            file_put_contents($configFile, $configContent);

                            echo "<div class='mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded'>";
                            echo "✅ Email configuration saved!";
                            echo "</div>";

                            echo "<a href='?step=5' class='w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500'>";
                            echo "Complete Installation";
                            echo "</a>";

                        } catch (Exception $e) {
                            echo "<div class='mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded'>";
                            echo "❌ Error updating configuration: " . htmlspecialchars($e->getMessage());
                            echo "</div>";
                        }
                        ?>
                    <?php endif; ?>

                    <?php if (!$_POST): ?>
                    <form method="POST" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Your Email Address</label>
                            <input type="email" name="email_user" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <p class="mt-1 text-sm text-gray-500">This email will send confirmation emails</p>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">Admin Email</label>
                            <input type="email" name="admin_email" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                            <p class="mt-1 text-sm text-gray-500">This email will receive bid notifications</p>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700">Company Name</label>
                            <input type="text" name="admin_name" value="SDC Creative Studio" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>

                        <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            Save Email Configuration
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
                <?php
            } elseif ($step == '5') {
                // Step 5: Complete
                ?>
                <div class="bg-white p-8 rounded-lg shadow text-center">
                    <div class="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100 mb-4">
                        <svg class="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                    </div>

                    <h3 class="text-lg font-medium text-gray-900 mb-4">Installation Complete!</h3>

                    <div class="space-y-4 text-sm text-gray-600">
                        <p>Your SDC Webform system has been successfully installed.</p>

                        <div class="bg-gray-50 p-4 rounded-md text-left">
                            <p class="font-medium mb-2">Quick Access Links:</p>
                            <ul class="space-y-1">
                                <li>• <a href="standalone-form.html" class="text-blue-600 hover:underline">Bid Request Form</a></li>
                                <li>• <a href="admin-dashboard.html" class="text-blue-600 hover:underline">Admin Dashboard</a></li>
                                <li>• <a href="api/health.php" class="text-blue-600 hover:underline">API Health Check</a></li>
                            </ul>
                        </div>

                        <div class="bg-yellow-50 p-4 rounded-md text-left">
                            <p class="font-medium mb-2 text-yellow-800">Security Note:</p>
                            <p class="text-yellow-700">Delete this install.php file after installation for security.</p>
                        </div>
                    </div>

                    <div class="mt-6">
                        <a href="standalone-form.html" class="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700">
                            Go to Bid Form
                        </a>
                    </div>
                </div>
                <?php
            }
            ?>
        </div>
    </div>
</body>
</html>