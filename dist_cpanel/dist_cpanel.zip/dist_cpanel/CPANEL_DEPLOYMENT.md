# cPanel Deployment Guide - SDC Webform

## 📋 Prerequisites

Before starting, make sure you have:
- Access to your cPanel hosting account
- A domain or subdomain set up
- PHP 7.4 or higher enabled
- MySQL database access
- Email account configured on your domain

## 🚀 Step-by-Step Deployment

### Step 1: Upload Files

1. **Download/Prepare Files**
   - Download all files from the `dist_cpanel` folder
   - You should have these files:
     - `index.html` (homepage)
     - `standalone-form.html` (main form)
     - `admin-dashboard.html` (admin panel)
     - `install.php` (installation wizard)
     - `config_template.php` (configuration template)
     - `database_setup.sql` (database structure)
     - `.htaccess` (URL rewriting and security)
     - `api/` folder with PHP backend files
     - `images/` folder with assets

2. **Upload to cPanel**
   - Log into your cPanel File Manager
   - Navigate to `public_html` (or your domain's folder)
   - Upload all files and folders
   - Extract if you uploaded a ZIP file

### Step 2: Create MySQL Database

1. **In cPanel MySQL Databases:**
   - Create a new database (e.g., `yourusername_sdc_webform`)
   - Create a database user (e.g., `yourusername_sdc_user`)
   - Add the user to the database with ALL privileges
   - Note down: database name, username, and password

### Step 3: Run Installation Wizard

1. **Navigate to Installation**
   - Go to `https://yourdomain.com/install.php`
   - The installation wizard will guide you through setup

2. **Follow Installation Steps:**
   - **Step 1:** System requirements check
   - **Step 2:** Database configuration
   - **Step 3:** Create database tables
   - **Step 4:** Email configuration
   - **Step 5:** Complete setup

### Step 4: Configure Email Settings

1. **Email Account Setup (in cPanel):**
   - Create an email account (e.g., `noreply@yourdomain.com`)
   - Note the email password

2. **SMTP Settings:**
   - Host: `localhost` (for cPanel)
   - Port: `587` (or `465` for SSL)
   - Use your domain email credentials

### Step 5: Security & Final Steps

1. **Delete Installation File:**
   ```bash
   # After installation is complete, delete install.php for security
   rm install.php
   ```

2. **Test Your Setup:**
   - Form: `https://yourdomain.com/standalone-form.html`
   - Admin: `https://yourdomain.com/admin-dashboard.html`
   - API Health: `https://yourdomain.com/api/health.php`

## 🔧 Configuration Details

### Database Configuration
Update `api/config.php` with your database details:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'yourusername_dbname');
define('DB_USER', 'yourusername_dbuser');
define('DB_PASS', 'your_db_password');
```

### Email Configuration
Update email settings in `api/config.php`:
```php
define('EMAIL_HOST', 'localhost');
define('EMAIL_USER', 'noreply@yourdomain.com');
define('EMAIL_PASS', 'your_email_password');
define('ADMIN_EMAIL', 'admin@yourdomain.com');
```

## 📁 File Structure

```
public_html/
├── index.html                   # Homepage
├── standalone-form.html         # Main bid form
├── admin-dashboard.html         # Admin dashboard
├── .htaccess                    # URL rewriting & security
├── images/                      # Image assets
│   └── [various images]
└── api/                         # PHP backend
    ├── .htaccess               # API URL routing
    ├── config.php              # Configuration
    ├── bid-request.php         # Main API endpoint
    ├── statistics.php          # Stats endpoint
    ├── health.php              # Health check
    └── email.php               # Email functions
```

## 🔐 Security Considerations

1. **File Permissions:**
   - Set folders to 755
   - Set files to 644
   - Set config.php to 600 (read-only by owner)

2. **Security Files:**
   - `.htaccess` blocks access to sensitive files
   - Rate limiting prevents spam submissions
   - Input validation prevents SQL injection

3. **Post-Installation:**
   - Delete `install.php` after setup
   - Keep `config_template.php` as backup only
   - Regularly backup your database

## 🎯 Testing Your Deployment

### 1. Health Check
Visit: `https://yourdomain.com/api/health.php`

Expected response:
```json
{
  "success": true,
  "message": "Server is running",
  "data": {
    "timestamp": "2024-01-01T12:00:00+00:00",
    "php_version": "8.1.0",
    "database_connected": true,
    "server": "yourdomain.com"
  }
}
```

### 2. Form Submission Test
1. Fill out the form at `standalone-form.html`
2. Submit and check for success message
3. Verify emails are sent (check admin email and client confirmation)
4. Check admin dashboard for the new entry

### 3. Admin Dashboard Test
1. Visit `admin-dashboard.html`
2. Verify bid requests appear
3. Test status updates
4. Check statistics display

## 🛠️ Troubleshooting

### Common Issues

**1. Database Connection Failed**
- Verify database credentials in config.php
- Check if database user has proper privileges
- Ensure database exists

**2. Emails Not Sending**
- Verify email account exists and password is correct
- Check cPanel email settings
- Test with a simple PHP mail() function

**3. Form Not Submitting**
- Check browser console for JavaScript errors
- Verify API endpoints are accessible
- Check .htaccess URL rewriting

**4. Permission Denied Errors**
- Set proper file permissions (755 for folders, 644 for files)
- Ensure PHP can write to necessary directories

### Debug Mode
To enable detailed error reporting, edit `api/config.php`:
```php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

**Remember to disable this in production!**

## 📞 Support

If you encounter issues:

1. **Check Error Logs:** cPanel → Error Logs
2. **Test API Endpoints:** Use browser or curl to test each endpoint
3. **Database Issues:** Use phpMyAdmin to verify tables and data
4. **Email Issues:** Test with cPanel's email test function

## 🎉 Success!

Once deployed, your SDC Webform system will be fully functional with:

- ✅ Professional bid request form
- ✅ Admin dashboard for managing requests
- ✅ Automatic email notifications
- ✅ Secure, rate-limited API
- ✅ Mobile-responsive design
- ✅ Production-ready security features

Your clients can now submit project requests at:
`https://yourdomain.com/standalone-form.html`

And you can manage them at:
`https://yourdomain.com/admin-dashboard.html`