# SDC Webform - cPanel Deployment Package

## 🚀 Quick Start

This package contains everything you need to deploy your SDC Webform system to cPanel hosting.

### 1. Upload Files
- Upload all files to your cPanel `public_html` directory
- Maintain the folder structure

### 2. Run Installation
- Visit: `https://yourdomain.com/install.php`
- Follow the guided installation process

### 3. Access Your System
- **Bid Form:** `https://yourdomain.com/standalone-form.html`
- **Admin Dashboard:** `https://yourdomain.com/admin-dashboard.html`

## 📁 What's Included

### Frontend Files
- `index.html` - Project homepage
- `standalone-form.html` - Main bid request form
- `admin-dashboard.html` - Admin management dashboard
- `images/` - Image assets and logos

### Backend Files (api/)
- `config.php` - Configuration (auto-created during installation)
- `bid-request.php` - Main API endpoint for form submissions
- `statistics.php` - Statistics API for admin dashboard
- `health.php` - System health check endpoint
- `email.php` - Email functionality
- `.htaccess` - API routing and security

### Setup Files
- `install.php` - Interactive installation wizard
- `database_setup.sql` - MySQL database structure
- `config_template.php` - Configuration template
- `.htaccess` - Main security and routing rules

### Documentation
- `CPANEL_DEPLOYMENT.md` - Detailed deployment guide
- `README_DEPLOYMENT.md` - This file

## ⚡ Features

- **Professional Form:** Dark-themed, mobile-responsive bid request form
- **Admin Dashboard:** Manage submissions, update statuses, view statistics
- **Email Notifications:** Automatic confirmations to clients and admin notifications
- **Security:** Rate limiting, input validation, SQL injection protection
- **Easy Installation:** Guided setup wizard
- **cPanel Optimized:** Designed specifically for shared hosting

## 🔧 Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- cPanel hosting with database access
- Email account on your domain

## 📞 Need Help?

1. Read `CPANEL_DEPLOYMENT.md` for detailed instructions
2. Check cPanel error logs for debugging
3. Test API health at `/api/health.php`

## 🛡️ Security Note

**After installation is complete:**
- Delete `install.php` for security
- Verify `.htaccess` files are uploaded properly
- Set proper file permissions (755 for folders, 644 for files)

---

**Ready to deploy?** Start with the installation wizard at `/install.php`